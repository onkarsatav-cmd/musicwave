const songs=[
{id:1,title:"Midnight Motion",artist:"Nova Lane",album:"Midnight",cover:"midnight.svg",audio:"midnight.wav",genres:["Chill Vibes"]},
{id:2,title:"Neon Drive",artist:"Echo Parks",album:"Neon Drive",cover:"neon-drive.svg",audio:"neon-drive.wav",genres:["Workout"]},
{id:3,title:"Afterglow",artist:"Luna Vale",album:"Afterglow",cover:"afterglow.svg",audio:"afterglow.wav",genres:["Chill Vibes"]},
{id:4,title:"Ocean Eyes",artist:"Blue Theory",album:"Ocean Eyes",cover:"ocean-eyes.svg",audio:"ocean-eyes.wav",genres:["Chill Vibes"]},
{id:5,title:"City Lights",artist:"The Night Owls",album:"City Lights",cover:"city-lights.svg",audio:"city-lights.wav",genres:["Workout"]},
{id:6,title:"Dream State",artist:"Mira Sol",album:"Dream State",cover:"dream-state.svg",audio:"dream-state.wav",genres:["Chill Vibes"]}
];

const audio=document.getElementById("audio");
let current=0, liked=JSON.parse(localStorage.getItem("musicwave-liked")||"[]"), shuffle=false, repeat=false;

const $=s=>document.querySelector(s);
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function card(song){
 const isLiked=liked.includes(song.id);
 return `<article class="music-card">
   <div class="cover-wrap"><img class="cover" src="assets/covers/${song.cover}" alt="${esc(song.title)} cover">
   <button class="card-play" onclick="playSong(${song.id})">▶</button></div>
   <div class="card-bottom"><div style="min-width:0"><div class="song-name">${esc(song.title)}</div><div class="artist">${esc(song.artist)}</div></div>
   <button class="heart ${isLiked?"liked":""}" onclick="toggleLike(${song.id})">${isLiked?"♥":"♡"}</button></div>
 </article>`;
}
function render(list, el){el.innerHTML=list.length?list.map(card).join(""):`<div class="empty" style="grid-column:1/-1">No songs found.</div>`}
function renderAll(){
 render(songs,$("#trendingGrid")); render(songs,$("#searchGrid")); render(songs.filter(s=>liked.includes(s.id)),$("#likedGrid"));
 $("#libraryCount").textContent=`${liked.length} liked song${liked.length===1?"":"s"}`;
 $("#emptyLiked").style.display=liked.length?"none":"block";
}
function playSong(id){
 current=songs.findIndex(s=>s.id===id); if(current<0)return;
 const s=songs[current]; audio.src=`assets/audio/${s.audio}`; audio.play().catch(()=>{});
 $("#playerTitle").textContent=s.title; $("#playerArtist").textContent=s.artist; $("#playerCover").src=`assets/covers/${s.cover}`;
 $("#playBtn").textContent="❚❚"; updateHeart();
}
function togglePlay(){ if(!audio.src){playSong(songs[0].id);return} if(audio.paused){audio.play();$("#playBtn").textContent="❚❚"}else{audio.pause();$("#playBtn").textContent="▶"}}
function next(){
 if(shuffle){current=Math.floor(Math.random()*songs.length)}
 else current=(current+1)%songs.length;
 playSong(songs[current].id);
}
function prev(){if(audio.currentTime>3){audio.currentTime=0;return}current=(current-1+songs.length)%songs.length;playSong(songs[current].id)}
function toggleLike(id){const i=liked.indexOf(id);if(i>=0)liked.splice(i,1);else liked.push(id);localStorage.setItem("musicwave-liked",JSON.stringify(liked));renderAll();updateHeart()}
function updateHeart(){if(!songs[current])return;const b=$("#likeCurrent");b.textContent=liked.includes(songs[current].id)?"♥":"♡";b.classList.toggle("liked",liked.includes(songs[current].id))}
function fmt(v){if(!isFinite(v))return"0:00";return `${Math.floor(v/60)}:${String(Math.floor(v%60)).padStart(2,"0")}`}
function showSection(id){document.querySelectorAll(".section").forEach(x=>x.classList.remove("active-section"));$("#"+id).classList.add("active-section");document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.section===id))}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showSection(b.dataset.section));
document.querySelectorAll(".playlist-link").forEach(b=>b.onclick=()=>{showSection("search");const name=b.dataset.playlist;render(songs.filter(s=>s.genres.includes(name)),$("#searchGrid"));$("#resultsTitle").textContent=name});
document.querySelectorAll(".text-btn").forEach(b=>b.onclick=()=>showSection(b.dataset.section));
$("#heroPlay").onclick=()=>playSong(songs[0].id);
document.querySelectorAll(".mini-play").forEach(b=>b.onclick=()=>{showSection("search");const list=songs.filter(s=>s.genres.includes(b.dataset.mix)); if(list.length)playSong(list[0].id)});
$("#playBtn").onclick=togglePlay;$("#nextBtn").onclick=next;$("#prevBtn").onclick=prev;
$("#shuffleBtn").onclick=()=>{shuffle=!shuffle;$("#shuffleBtn").style.color=shuffle?"#fff":""};
$("#repeatBtn").onclick=()=>{repeat=!repeat;$("#repeatBtn").style.color=repeat?"#fff":""};
$("#likeCurrent").onclick=()=>songs[current]&&toggleLike(songs[current].id);
$("#volume").oninput=e=>audio.volume=e.target.value;
$("#progress").oninput=e=>{if(audio.duration)audio.currentTime=(e.target.value/100)*audio.duration};
audio.addEventListener("timeupdate",()=>{if(audio.duration){$("#progress").value=(audio.currentTime/audio.duration)*100}$("#currentTime").textContent=fmt(audio.currentTime);$("#duration").textContent=fmt(audio.duration)});
audio.addEventListener("ended",()=>{if(repeat){audio.currentTime=0;audio.play()}else next()});
$("#searchInput").oninput=e=>{const q=e.target.value.toLowerCase().trim();const list=songs.filter(s=>[s.title,s.artist,s.album].some(v=>v.toLowerCase().includes(q)));$("#resultsTitle").textContent=q?`Results for "${e.target.value}"`:"All songs";render(list,$("#searchGrid"))};
$("#themeBtn").onclick=()=>document.body.classList.toggle("light");
$("#backBtn").onclick=()=>window.history.back();$("#forwardBtn").onclick=()=>window.history.forward();
renderAll(); audio.volume=.75;
